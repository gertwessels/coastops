# -*- coding: utf-8 -*-
"""
Created on Tue Aug  2 09:55:12 2016

@author: gwessels
"""
import datetime as dt
import pandas as pd
from import_data import import_ncep_text_file

def main():
    ret = import_ncep_text_file('data/ncepData/NG.dat')

    generate_wavecon('test08_1',dt.datetime(2016,7,4,8,0),dt.datetime(2016,7,4,8,0),dt.datetime(2016,7,4,23,0),180,ret['Ocean_HDF'],ret['Atmos_HDF'])
    generate_wnd('test08_1',dt.datetime(2016,7,4,8,0),dt.datetime(2016,7,4,8,0),dt.datetime(2016,7,4,23,0),180,ret['Atmos_HDF'])


def minutes_from_refdate(date,refdate=dt.datetime(1900,1,1),):
    delta = pd.Timestamp(date) - pd.Timestamp(refdate)
    return delta.days*24*60 + delta.seconds/60

def generate_wavecon(runid,ref_date,start_date,end_date,dt_min,ocean_hdf,atmos_hdf,ms=25,wl=0.0):
    
#    print ref_date
#    print start_date
#    print end_date
#    print dt_min

#    print len(ocean_hdf), len(atmos_hdf)    
    
    hdr = "* Itdata   Hs   Tp   Dir   ms   wl   windspeed   winddir\nBL01\n"
    date = start_date
    row = 0
    text = ''
    
#    print ref_date
#    print start_date
#    print end_date
#    print dt_min
    
    
    while date<=end_date+dt.timedelta(minutes=dt_min):
        atmos = atmos_hdf[atmos_hdf.date_time == date.strftime('%Y-%m-%d %H:%M:%S')]
        ocean = ocean_hdf[ocean_hdf.date_time == date.strftime('%Y-%m-%d %H:%M:%S')]
        
#        print ocean
#        print atmos
        
        text = text + "{:7.1f}".format(minutes_from_refdate(date,ref_date))
        text = text + "{:8.3f}".format(ocean.sign_wave_height.values[0])+"{:8.3f}".format(ocean.peak_wave_period.values[0])
        text = text + "{:9.3f}".format(ocean.peak_wave_dir.values[0])+"{:6.1f}".format(ms)+"{:8.2f}".format(wl)
        text = text + "{:9.3f}".format(atmos.windspeed.values[0])+"{:9.3f}".format(atmos.winddir.values[0])+'\n'

        row = row +1
        date = date+dt.timedelta(minutes=dt_min)
    
    text = hdr+'  '+str(row)+'   8\n'+text
    
    with open('wavecon.'+runid,'w') as f:
        f.write(text)
        
def generate_wnd(runid,ref_date,start_date,end_date,dt_min,atmos_hdf):

    date = start_date
    text = ''
    
    while date<=end_date+dt.timedelta(minutes=dt_min):
        atmos = atmos_hdf[atmos_hdf.date_time == date.strftime('%Y/%m/%d %H:%M:%S')]
        text = text + "{:7.1f}".format(minutes_from_refdate(date,ref_date))
        text = text + "{:9.3f}".format(atmos.windspeed.values[0])+"{:9.3f}".format(atmos.winddir.values[0])+'\n'

        date = date+dt.timedelta(minutes=dt_min)
            
    with open(runid+'.wnd','w') as f:
        f.write(text)
        
        
if __name__ == '__main__':
    main()
